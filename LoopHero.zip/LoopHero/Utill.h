#pragma once
#include <string>
#include <vector>

using namespace std;

double StackCalculate(string text);
vector<string> StringSplit(string str, char token);
