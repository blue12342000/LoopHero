#pragma once
#include "GameUI.h"

class UIProgressBar : public GameUI
{
};

