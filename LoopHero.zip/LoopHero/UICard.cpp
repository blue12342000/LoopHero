#include "UICard.h"
#include "Card.h"

void UICard::Init(UI_ANCHOR anchor, POINTFLOAT pos, int width, int height)
{
	GameUI::Init(anchor, pos, width, height);
}

void UICard::Render(HDC hdc)
{

}
